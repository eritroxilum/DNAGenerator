# DNAGenerator
SoftwareEngineering Projekt FH Bingen. DNA translation trainer
